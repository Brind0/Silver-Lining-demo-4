"use client"
import { useState, useEffect } from "react"
import { MainLayout } from "@/components/main-layout"
import { SwipeablePanel } from "@/components/swipeable-panel"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { OverrideStatusModal } from "@/components/override-status-modal"
import { AnimatedCounter } from "@/components/animated-counter"
import { toast } from "sonner"
import {
  DollarSign,
  FolderOpen,
  TrendingUp,
  TrendingDown,
  Building,
  Gamepad2,
  Users,
  FileText,
  UserPlus,
  CreditCard,
  CheckCircle,
  AlertTriangle,
} from "lucide-react"

export default function DashboardPage() {
  const [showOverrideModal, setShowOverrideModal] = useState(false)
  const [selectedProject, setSelectedProject] = useState<any>(null)
  const [projects, setProjects] = useState([
    {
      id: 1,
      name: "Henderson Golf Sim",
      type: "Golf Simulator",
      status: "AMBER" as const,
      budget: 45000,
      spent: 38000,
      progress: 75,
      daysRemaining: 12,
      keyMetric: "6% over budget",
      icon: Gamepad2,
    },
    {
      id: 2,
      name: "Marchmont Historic",
      type: "Heritage Restoration",
      status: "RED" as const,
      budget: 120000,
      spent: 165000,
      progress: 85,
      daysRemaining: -5,
      keyMetric: "37.5% over budget",
      icon: Building,
    },
    {
      id: 3,
      name: "Wentworth Golf Sim",
      type: "Golf Simulator",
      status: "GREEN" as const,
      budget: 65000,
      spent: 22000,
      progress: 40,
      daysRemaining: 28,
      keyMetric: "On track",
      icon: Gamepad2,
    },
    {
      id: 4,
      name: "Tunbridge Restoration",
      type: "Heritage Restoration",
      status: "AMBER" as const,
      budget: 78000,
      spent: 71000,
      progress: 90,
      daysRemaining: 8,
      keyMetric: "9% over budget",
      icon: Building,
    },
    {
      id: 5,
      name: "Ascot Entertainment",
      type: "Golf Simulator",
      status: "GREEN" as const,
      budget: 92000,
      spent: 28000,
      progress: 35,
      daysRemaining: 42,
      keyMetric: "Under budget",
      icon: Gamepad2,
    },
  ])

  const recentActivity = [
    {
      action: "Receipt approved",
      project: "Henderson Golf Sim",
      time: "2 min ago",
      icon: FileText,
      color: "text-blue-600",
    },
    {
      action: "Budget alert triggered",
      project: "Marchmont Historic",
      time: "15 min ago",
      icon: AlertTriangle,
      color: "text-amber-600",
    },
    {
      action: "Phase completed",
      project: "Wentworth Golf Sim",
      time: "1 hour ago",
      icon: CheckCircle,
      color: "text-emerald-600",
    },
    {
      action: "Invoice submitted",
      project: "Tunbridge Restoration",
      time: "2 hours ago",
      icon: FileText,
      color: "text-blue-600",
    },
    {
      action: "Team member assigned",
      project: "Ascot Entertainment",
      time: "3 hours ago",
      icon: UserPlus,
      color: "text-blue-600",
    },
    {
      action: "Payment processed",
      project: "Henderson Golf Sim",
      time: "4 hours ago",
      icon: CreditCard,
      color: "text-emerald-600",
    },
  ]

  useEffect(() => {
    const timer = setTimeout(() => {
      toast.error("Critical Project Alert", {
        description: "Marchmont Historic: £45,000 over budget - requires immediate attention",
        action: {
          label: "View Project",
          onClick: () => console.log("Navigate to project"),
        },
        duration: 10000,
      })
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  const handleOverrideStatus = (project: any) => {
    setSelectedProject(project)
    setShowOverrideModal(true)
  }

  const handleOverrideSubmit = (reason: string) => {
    console.log(`Status override for ${selectedProject?.name}: ${reason}`)
    toast.success("Status Override Saved", {
      description: `Override reason recorded for ${selectedProject?.name}`,
    })
  }

  const handleProjectMove = (projectId: number, newStatus: string) => {
    const project = projects.find((p) => p.id === projectId)
    if (project) {
      setProjects((prev) =>
        prev.map((p) => (p.id === projectId ? { ...p, status: newStatus as "GREEN" | "AMBER" | "RED" } : p)),
      )
      toast.success("Project Status Updated", {
        description: `${project.name} moved to ${
          newStatus === "GREEN" ? "On Track" : newStatus === "AMBER" ? "At Risk" : "Critical"
        }`,
      })
    }
  }

  return (
    <MainLayout>
      <div className="h-screen overflow-hidden bg-gray-50 flex flex-col">
        <div className="flex items-center justify-between border-b border-gray-200 bg-white px-6 py-3 flex-shrink-0">
          <div>
            <h1 className="text-xl font-bold text-primary-900">Dashboard</h1>
            <p className="text-sm text-gray-600">Welcome back, Emily. Here's your business overview</p>
          </div>
          <div className="flex space-x-2">
            <div className="px-3 py-2 bg-green-50 text-green-800 text-xs font-medium rounded-lg border border-green-200 flex items-center justify-center">
              System Operational
            </div>
          </div>
        </div>

        <div className="px-6 py-3 bg-white border-b border-gray-200 flex-shrink-0">
          <div className="grid grid-cols-4 gap-4">
            <Card className="border border-primary-900 bg-white shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-1">
                <CardTitle className="text-xs font-medium text-gray-600">Total Project Value</CardTitle>
                <DollarSign className="h-3 w-3 text-primary-900" />
              </CardHeader>
              <CardContent className="pb-2">
                <div className="text-lg font-bold text-primary-900">
                  <AnimatedCounter end={487000} prefix="£" />
                </div>
                <p className="text-xs text-gray-500 flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1 text-emerald-600" />
                  +12.5%
                </p>
              </CardContent>
            </Card>

            <Card className="border border-primary-900 bg-white shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-1">
                <CardTitle className="text-xs font-medium text-gray-600">Active Projects</CardTitle>
                <FolderOpen className="h-3 w-3 text-primary-900" />
              </CardHeader>
              <CardContent className="pb-2">
                <div className="text-lg font-bold text-primary-900">
                  <AnimatedCounter end={5} />
                </div>
                <div className="flex space-x-1">
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div>
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div>
                  <div className="w-1.5 h-1.5 bg-amber-500 rounded-full"></div>
                  <div className="w-1.5 h-1.5 bg-amber-500 rounded-full"></div>
                  <div className="w-1.5 h-1.5 bg-red-500 rounded-full"></div>
                </div>
              </CardContent>
            </Card>

            <Card className="border border-primary-900 bg-white shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-1">
                <CardTitle className="text-xs font-medium text-gray-600">Cost Variance</CardTitle>
                <TrendingDown className="h-3 w-3 text-primary-900" />
              </CardHeader>
              <CardContent className="pb-2">
                <div className="text-lg font-bold text-red-600">
                  <AnimatedCounter end={8.2} suffix="%" prefix="+" />
                </div>
                <p className="text-xs text-gray-500">Above planned</p>
              </CardContent>
            </Card>

            <Card className="border border-primary-900 bg-white shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-1">
                <CardTitle className="text-xs font-medium text-gray-600">Team Members</CardTitle>
                <Users className="h-3 w-3 text-primary-900" />
              </CardHeader>
              <CardContent className="pb-2">
                <div className="text-lg font-bold text-primary-900">
                  <AnimatedCounter end={12} />
                </div>
                <p className="text-xs text-gray-500">Across projects</p>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="flex-1 px-6 py-4 overflow-hidden">
          <div className="grid grid-cols-3 gap-6 h-full">
            <div className="col-span-2 h-full">
              <SwipeablePanel
                projects={projects}
                onProjectMove={handleProjectMove}
                onOverrideStatus={handleOverrideStatus}
              />
            </div>

            <div className="col-span-1 h-full">
              <Card className="border border-gray-200 bg-white shadow-sm h-full flex flex-col gap-2">
                <CardHeader className="border-gray-200 mb-0 leading-4 border-b-0 py-1">
                  <CardTitle className="text-lg font-bold text-primary-900 mb-0">Recent Activity</CardTitle>
                </CardHeader>
                <CardContent className="p-2 overflow-y-auto flex-1 px-3.5">
                  <div className="space-y-1">
                    {recentActivity.map((activity, index) => {
                      const IconComponent = activity.icon
                      return (
                        <div
                          key={index}
                          className={`py-1 border-b border-gray-100 last:border-b-0 ${index === 0 ? "mt-0" : ""}`}
                        >
                          <div className="flex items-center space-x-2">
                            <IconComponent className={`w-3 h-3 ${activity.color}`} />
                            <p className="text-sm text-primary-900 font-medium">{activity.action}</p>
                          </div>
                          <p className="text-xs text-gray-600 ml-5">{activity.project}</p>
                          <span className="text-xs text-gray-500 ml-5">{activity.time}</span>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      <OverrideStatusModal
        open={showOverrideModal}
        onOpenChange={setShowOverrideModal}
        projectName={selectedProject?.name || ""}
        currentStatus={selectedProject?.status || ""}
        onOverride={handleOverrideSubmit}
      />
    </MainLayout>
  )
}
