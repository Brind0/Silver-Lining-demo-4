"use client"

import type React from "react"
import { useState, useRef } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, AlertTriangle, XCircle, Calendar, DollarSign, TrendingUp, TrendingDown } from "lucide-react"

interface Project {
  id: number
  name: string
  type: string
  status: "GREEN" | "AMBER" | "RED"
  budget: number
  spent: number
  progress: number
  daysRemaining: number
  keyMetric: string
  icon: any
}

interface SwipeablePanelProps {
  projects: Project[]
  onProjectMove: (projectId: number, newStatus: string) => void
  onOverrideStatus: (project: Project) => void
}

export const SwipeablePanel: React.FC<SwipeablePanelProps> = ({ projects, onProjectMove, onOverrideStatus }) => {
  const [currentPanel, setCurrentPanel] = useState(0)
  const [touchStart, setTouchStart] = useState(0)
  const [touchEnd, setTouchEnd] = useState(0)
  const [draggedProject, setDraggedProject] = useState<Project | null>(null)
  const panelRef = useRef<HTMLDivElement>(null)

  const SWIPE_THRESHOLD = 50

  const onTrackProjects = projects.filter((p) => p.status === "GREEN")
  const atRiskProjects = projects.filter((p) => p.status === "AMBER")
  const criticalProjects = projects.filter((p) => p.status === "RED")

  const upcomingDeadlines = [
    { project: "Henderson Golf Sim", task: "Final inspection", date: "Dec 15", daysLeft: 3, priority: "high" },
    { project: "Tunbridge Restoration", task: "Heritage approval", date: "Dec 17", daysLeft: 5, priority: "medium" },
    { project: "Wentworth Golf Sim", task: "Equipment delivery", date: "Dec 20", daysLeft: 8, priority: "low" },
    { project: "Ascot Entertainment", task: "Site preparation", date: "Dec 24", daysLeft: 12, priority: "low" },
    { project: "Marchmont Historic", task: "Budget review", date: "Dec 13", daysLeft: 1, priority: "critical" },
  ]

  const financialData = {
    totalBudget: 400000,
    totalSpent: 324000,
    variance: 8.2,
    monthlyBurn: 45000,
    projectedCompletion: 420000,
    costsByCategory: [
      { category: "Materials", budgeted: 180000, spent: 165000, variance: -8.3 },
      { category: "Labor", budgeted: 120000, spent: 98000, variance: -18.3 },
      { category: "Equipment", budgeted: 60000, spent: 45000, variance: -25.0 },
      { category: "Permits", budgeted: 25000, spent: 16000, variance: -36.0 },
      { category: "Other", budgeted: 15000, spent: 12000, variance: -20.0 },
    ],
  }

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX)
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX)
  }

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return

    const distance = touchStart - touchEnd
    const isLeftSwipe = distance > SWIPE_THRESHOLD
    const isRightSwipe = distance < -SWIPE_THRESHOLD

    if (isLeftSwipe && currentPanel < 2) {
      setCurrentPanel((prev) => prev + 1)
    }
    if (isRightSwipe && currentPanel > 0) {
      setCurrentPanel((prev) => prev - 1)
    }
  }

  const handleDragStart = (e: React.DragEvent, project: Project) => {
    setDraggedProject(project)
    e.dataTransfer.effectAllowed = "move"
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.dataTransfer.dropEffect = "move"
  }

  const handleDrop = (e: React.DragEvent, newStatus: string) => {
    e.preventDefault()
    if (draggedProject && draggedProject.status !== newStatus) {
      onProjectMove(draggedProject.id, newStatus)
    }
    setDraggedProject(null)
  }

  const ProjectCard = ({ project }: { project: Project }) => {
    const IconComponent = project.icon
    return (
      <Card
        className="bg-white border border-gray-200 cursor-move transition-all duration-200 hover:shadow-sm"
        draggable
        onDragStart={(e) => handleDragStart(e, project)}
        onClick={() => onOverrideStatus(project)}
      >
        <CardContent className="p-2">
          <div className="flex items-center space-x-2 mb-1">
            <IconComponent className="h-3 w-3 text-primary-700" />
            <h4 className="font-medium text-primary-900 text-xs truncate">{project.name}</h4>
          </div>
          <p className="text-xs text-gray-500 mb-1">{project.keyMetric}</p>
          <div className="flex justify-between text-xs">
            <span className="text-gray-500">£{project.spent.toLocaleString()}</span>
            <span className={project.daysRemaining < 0 ? "text-red-600" : "text-gray-500"}>
              {project.daysRemaining < 0 ? `${Math.abs(project.daysRemaining)}d over` : `${project.daysRemaining}d`}
            </span>
          </div>
        </CardContent>
      </Card>
    )
  }

  const ProjectHealthPanel = () => (
    <div className="h-full">
      <div className="grid grid-cols-3 gap-4 h-full">
        <div
          className="bg-emerald-50 rounded-lg p-3"
          onDragOver={handleDragOver}
          onDrop={(e) => handleDrop(e, "GREEN")}
        >
          <div className="flex items-center space-x-2 mb-3">
            <CheckCircle className="w-4 h-4 text-emerald-600" />
            <h3 className="font-semibold text-primary-900">On Track</h3>
            <Badge variant="outline" className="bg-emerald-100 text-emerald-700 border-emerald-200">
              {onTrackProjects.length}
            </Badge>
          </div>
          <div className="space-y-2 overflow-y-auto h-[calc(100%-3rem)]">
            {onTrackProjects.map((project) => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </div>
        </div>

        <div className="bg-amber-50 rounded-lg p-3" onDragOver={handleDragOver} onDrop={(e) => handleDrop(e, "AMBER")}>
          <div className="flex items-center space-x-2 mb-3">
            <AlertTriangle className="w-4 h-4 text-amber-600" />
            <h3 className="font-semibold text-primary-900">At Risk</h3>
            <Badge variant="outline" className="bg-amber-100 text-amber-700 border-amber-200">
              {atRiskProjects.length}
            </Badge>
          </div>
          <div className="space-y-2 overflow-y-auto h-[calc(100%-3rem)]">
            {atRiskProjects.map((project) => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </div>
        </div>

        <div className="bg-red-50 rounded-lg p-3" onDragOver={handleDragOver} onDrop={(e) => handleDrop(e, "RED")}>
          <div className="flex items-center space-x-2 mb-3">
            <XCircle className="w-4 h-4 text-red-600" />
            <h3 className="font-semibold text-primary-900">Critical</h3>
            <Badge variant="outline" className="bg-red-100 text-red-700 border-red-200">
              {criticalProjects.length}
            </Badge>
          </div>
          <div className="space-y-2 overflow-y-auto h-[calc(100%-3rem)]">
            {criticalProjects.map((project) => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </div>
        </div>
      </div>
    </div>
  )

  const UpcomingDeadlinesPanel = () => (
    <div className="h-full p-4">
      <h3 className="text-lg font-semibold text-primary-900 mb-4 flex items-center">
        <Calendar className="w-5 h-5 mr-2 text-primary-700" />
        Upcoming Deadlines
      </h3>
      <div className="space-y-3 overflow-y-auto h-[calc(100%-4rem)]">
        {upcomingDeadlines.map((deadline, index) => (
          <div
            key={index}
            className="flex items-center space-x-4 p-3 bg-white rounded-lg border border-gray-200 hover:bg-gray-50"
          >
            <div className="flex-shrink-0">
              <div
                className={`w-3 h-3 rounded-full ${
                  deadline.priority === "critical"
                    ? "bg-red-500"
                    : deadline.priority === "high"
                      ? "bg-amber-500"
                      : deadline.priority === "medium"
                        ? "bg-blue-500"
                        : "bg-gray-400"
                }`}
              />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-primary-900 truncate">{deadline.task}</p>
              <p className="text-xs text-gray-600">{deadline.project}</p>
            </div>
            <div className="flex-shrink-0 text-right">
              <p className="text-xs text-gray-500">{deadline.date}</p>
              <p
                className={`text-xs font-medium ${
                  deadline.priority === "critical"
                    ? "text-red-700"
                    : deadline.priority === "high"
                      ? "text-amber-700"
                      : "text-gray-600"
                }`}
              >
                {deadline.daysLeft}d
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )

  const FinancialOverviewPanel = () => (
    <div className="h-full p-4">
      <h3 className="text-lg font-semibold text-primary-900 mb-4 flex items-center">
        <DollarSign className="w-5 h-5 mr-2 text-primary-700" />
        Financial Overview
      </h3>
      <div className="space-y-4 overflow-y-auto h-[calc(100%-4rem)]">
        <div className="grid grid-cols-2 gap-3">
          <Card className="p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-600">Total Spent</p>
                <p className="text-lg font-bold text-primary-900">£{financialData.totalSpent.toLocaleString()}</p>
              </div>
              <TrendingUp className="w-4 h-4 text-red-500" />
            </div>
          </Card>
          <Card className="p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-600">Variance</p>
                <p className="text-lg font-bold text-red-600">+{financialData.variance}%</p>
              </div>
              <TrendingDown className="w-4 h-4 text-red-500" />
            </div>
          </Card>
        </div>

        <Card className="p-3">
          <div className="flex justify-between text-sm mb-2">
            <span className="text-gray-600">Budget Utilization</span>
            <span className="font-medium text-primary-900">
              £{financialData.totalSpent.toLocaleString()} / £{financialData.totalBudget.toLocaleString()}
            </span>
          </div>
          <Progress value={(financialData.totalSpent / financialData.totalBudget) * 100} className="h-2" />
        </Card>

        <div className="space-y-2">
          <h4 className="text-sm font-medium text-primary-900">Cost Breakdown</h4>
          {financialData.costsByCategory.map((category, index) => (
            <div key={index} className="flex items-center justify-between p-2 bg-white rounded border border-gray-200">
              <span className="text-sm text-gray-700">{category.category}</span>
              <div className="text-right">
                <p className="text-sm font-medium text-primary-900">£{category.spent.toLocaleString()}</p>
                <p className={`text-xs ${category.variance < 0 ? "text-emerald-600" : "text-red-600"}`}>
                  {category.variance > 0 ? "+" : ""}
                  {category.variance.toFixed(1)}%
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )

  const panels = [
    { id: "project-health", title: "Project Health Overview", content: <ProjectHealthPanel /> },
    { id: "deadlines", title: "Upcoming Deadlines", content: <UpcomingDeadlinesPanel /> },
    { id: "financial", title: "Financial Overview", content: <FinancialOverviewPanel /> },
  ]

  return (
    <div className="h-full bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
      <div
        ref={panelRef}
        className="h-full overflow-hidden relative"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        <div
          className="flex h-full"
          style={{
            transform: `translateX(-${currentPanel * 100}%)`,
            transition: "transform 0.5s cubic-bezier(0.4, 0.0, 0.2, 1)",
          }}
        >
          {panels.map((panel) => (
            <div key={panel.id} className="min-w-full h-full">
              {panel.content}
            </div>
          ))}
        </div>

        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
          {panels.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentPanel(i)}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                i === currentPanel ? "bg-primary-600 scale-110" : "bg-gray-300 hover:bg-gray-400"
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
